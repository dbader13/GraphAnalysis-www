#include "defs.h"

double getStartLists(graph* G, edge** maxIntWtListPtr, 
        INT_T* maxIntWtListSizePtr) {

    LONG_T nthreads, tid, chunkSize;
    LONG_T i, j, n, m, *local_max, maxWeight;
    LONG_T maxIntWtListSize, pCount, tmpListSize;
    edge *maxIntWtList, *pList;
    LONG_T *p_start, *p_end;
    double time = 0;

#pragma omp parallel \
private(tid, nthreads, i, j, n, m, pList, pCount, tmpListSize) 
{
    edge* pList2;
    tid = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    
    if (tid == 0)  
        time = omp_get_wtime();
    
    n = G->n;
    m = G->m;

    if (tid == 0) {
        local_max = (LONG_T *) malloc(nthreads*sizeof(LONG_T));
    }

    #pragma omp barrier

    local_max[tid] = -1;

    chunkSize = m/nthreads;
    #pragma omp for schedule(static, chunkSize)
    for (i=0; i<m; i++) {
        if (G->weight[i] > local_max[tid]) {
            local_max[tid] = G->weight[i];
        }   
    }
   
    if (tid == 0) {
        maxWeight = local_max[0];

        for (i=1; i<nthreads; i++) {
            if (local_max[i] > maxWeight)
                  maxWeight = local_max[i];
        }
        free(local_max);
    }
   
    /* Allocate memory for partial edge list on each thread */
    tmpListSize = 10;
    pList = (edge *) malloc(tmpListSize*sizeof(edge));
    pCount = 0;

    #pragma omp barrier

    #pragma omp for
    for (i=0; i<m; i++) {
        if (G->weight[i] == maxWeight) {
            pList[pCount].endVertex = G->endV[i];
            pList[pCount].e = i;
            pList[pCount].w = maxWeight;
            pCount++;
            if (pCount == tmpListSize) {
                /* Allocate more memory */
                pList2 = (edge*) malloc(2*tmpListSize*sizeof(edge));
                memcpy(pList2, pList, tmpListSize*sizeof(edge));
                tmpListSize = tmpListSize * 2;
                free(pList);
                pList = pList2;
            }
        }
    }
  
    /* Merge partial edge lists */
    if (tid == 0) {
        p_start = (LONG_T *) malloc(nthreads*sizeof(LONG_T));
        p_end = (LONG_T *) malloc(nthreads*sizeof(LONG_T));
    }

    #pragma omp barrier

    p_end[tid] = pCount;
    p_start[tid] = 0;
  
    #pragma omp barrier

    if (tid == 0) {
        for (i=1; i<nthreads; i++) {
            p_end[i] = p_end[i-1] + p_end[i];
            p_start[i] = p_end[i-1]; 
        }

        maxIntWtListSize = p_end[nthreads-1];
        free(*maxIntWtListPtr);
        maxIntWtList = (edge *) malloc((maxIntWtListSize)*sizeof(edge));
    }

    #pragma omp barrier

    for (j=p_start[tid]; j<p_end[tid]; j++) {
        (maxIntWtList[j]).endVertex = pList[j-p_start[tid]].endVertex;
        (maxIntWtList[j]).e = pList[j-p_start[tid]].e;
        (maxIntWtList[j]).w = pList[j-p_start[tid]].w;
    } 

    #pragma omp barrier

    #pragma omp for schedule(dynamic)
    for (i=0; i<maxIntWtListSize; i++) {    
        maxIntWtList[i].startVertex = 
            BinarySearchEdgeListL(G->numEdges, n, maxIntWtList[i].e);
    }

    free(pList);

    if (tid == 0) {
        free(p_start);
        free(p_end);
        *maxIntWtListPtr = maxIntWtList;
        *maxIntWtListSizePtr = maxIntWtListSize;
        time = omp_get_wtime() - time;
    }
    

}
    /*    
    maxIntWtList = *maxIntWtListPtr;
    for (i=0; i<*maxIntWtListSizePtr; i++) {
        fprintf(stderr, "[%ld %ld %ld %ld] ", maxIntWtList[i].startVertex, 
                maxIntWtList[i].endVertex, maxIntWtList[i].e, maxIntWtList[i].w);
    }
    */ 
    return time;
}
