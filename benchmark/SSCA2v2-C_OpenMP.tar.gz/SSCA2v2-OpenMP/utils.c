#include "defs.h"

double get_seconds() {
    struct timeval tp;
    gettimeofday(&tp, NULL);
    return (double) (tp.tv_sec + ((1e-6)*tp.tv_usec));
}

void prefix_sums(LONG_T *input, LONG_T* result, LONG_T* p, LONG_T n) {

    LONG_T i, j, r, start, end, add_value;
    LONG_T tid, nthreads;

    tid = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    r = n/nthreads;

    result[0] = 0;

    #pragma omp for schedule(static, n/nthreads)
    for(i=1; i<n+1; i++)
        result[i] = input[i-1];

    start =  tid*r + 1;
    end   = (tid+1)*r;

    if (tid == nthreads-1)
        end = n+1;

    for (j=start; j<end; j++)
        result[j] = input[j-1] + result[j-1];

    p[tid] = result[end-1];

    #pragma omp barrier

    if (tid == 0) {
        for (j=1; j<nthreads; j++)
            p[j] += p[j-1];
    }

    #pragma omp barrier

    if (tid>0) {
        add_value=p[tid-1];
        for (j=start-1; j<end; j++)
            result[j] += add_value;
    }

    #pragma omp barrier

}

LONG_T BinarySearchEdgeListL(LONG_T* array, LONG_T m, LONG_T i) {

    LONG_T h, l, md;

    if (i==0)
        return 0;

    h = m;
    l = 0;

    while (h-l > 0) {

        md = (h+l)/2;

        if ((array[md] <= i) && (array[md+1] > i)) {
            return md;
        }

        if (array[md] > i) {
            h = md;
        }

        if ((array[md] <= i) && (array[md+1] <= i)) {
            l = md+1;
        }
    }

    return (md-1);
}

void dynArraySortedInsert(dynArray* l, LONG_T elem, LONG_T pos) {

    LONG_T i;
    LONG_T* newArray;

    if (l->count == ARRAY_INIT_SIZE) {
        
        /* double the size */
        newArray = (long *) malloc(2*ARRAY_INIT_SIZE*sizeof(long));
        l->max_size = 2*ARRAY_INIT_SIZE;
        for (i=0; i<l->count; i++) {
            newArray[i] = (l->vals)[i];
        }
        l->vals = newArray;

    } else if (l->count == l->max_size) {

        /* double the size */
        newArray = (long *) malloc(2*(l->max_size)*sizeof(long));
        l->max_size = 2 * (l->max_size);
        for (i=0; i<l->count; i++) {
            newArray[i] = (l->vals)[i];
        }
        free(l->vals);
        l->vals = newArray;

    }
    
    /* shift all the values to the right */
    for (i=l->count-1; i>=pos; i--) {
        (l->vals)[i+1] = (l->vals)[i];    
    }

    /* insert in correct position */
    (l->vals)[pos] = elem;
    l->count = l->count + 1;

}

LONG_T dynArraySortedInsertPos(dynArray* l, LONG_T elem) {

    LONG_T i;

    if (l->count==0) {
        return 0;
    }
    
    for (i=0; i<l->count; i++) {
        if ((l->vals)[i] == elem)
            return -1;
        if ((l->vals)[i] > elem)
            return i;
    }
    
    return l->count;
}

void initDynArray(dynArray* l) {
    
    l->vals = NULL;
    l->count = 0;
    l->max_size = 0;

}

void clearDynArray(dynArray* l) {

    l->count = 0;

}

void freeDynArray(dynArray* l) {
    if (l->vals != NULL)
        free(l->vals);
}


void dynArrayInsert(dynArray* l, LONG_T elem) {

    LONG_T* newVals;
    LONG_T i;

    if (l->max_size == 0) {

        /* Create a new list */
        l->vals = (long *) malloc(ARRAY_INIT_SIZE*sizeof(long));
        l->max_size = ARRAY_INIT_SIZE;
        l->vals[0] = elem;
        l->count = 1;
        // fprintf(stderr, "created ");
        return;
    }

    if (l->max_size != l->count) {
        l->vals[l->count] = elem;
        l->count = l->count + 1;
        return;

    } else {

        /* Increase array capacity by ARRAY_INIT_SIZE */
        l->max_size = l->max_size + ARRAY_INIT_SIZE;
        newVals = (LONG_T *) malloc(l->max_size*sizeof(LONG_T));
        for (i=0; i<l->count; i++) {
            newVals[i] = l->vals[i];
        }
        free(l->vals);
        l->vals = newVals;
        l->vals[l->count] = elem;
        l->count = l->count + 1;
        return;
    }
}
