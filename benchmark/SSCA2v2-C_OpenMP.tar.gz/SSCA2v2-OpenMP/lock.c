#include "defs.h"

#ifdef GENERIC
    omp_lock_t* vLock;
#endif
    
void initLockArr(LONG_T n, LONG_T tid) {
    int i;

#ifdef GENERIC
    if (tid == 0) {
        vLock = (omp_lock_t *) malloc(n*sizeof(omp_lock_t));
    }
  
    #pragma omp barrier
 
    #pragma omp for schedule(static)
    for (i=0; i<n; i++) {
        omp_init_lock(&vLock[i]);
    }
#endif
    
}

LONG_T fetch_and_add_long(LONG_T *val, LONG_T u, LONG_T incr) {

    LONG_T retval;

#ifdef GENERIC
    omp_set_lock(&vLock[u]);
    retval = *val;
    *val = *val + incr;
    omp_unset_lock(&vLock[u]);
#endif

#ifdef ITANIUM2
    retval = __sync_fetch_and_add(&val, incr);
#endif

    return retval;
}

DOUBLE_T fetch_and_add_double(DOUBLE_T *val, LONG_T u, DOUBLE_T incr) {

    DOUBLE_T retval;

#ifdef GENERIC
    omp_set_lock(&vLock[u]);
    retval = *val;
    *val = *val + incr;
    omp_unset_lock(&vLock[u]);
#endif

#ifdef ITANIUM2
    retval = __sync_fetch_and_add(&val, incr);
#endif
    
    return retval;
}

void destroyLockArr(LONG_T n, LONG_T tid) {

    int i;

#ifdef GENERIC
    
    #pragma omp for schedule(static)
    for (i=0; i<n; i++) {
        omp_destroy_lock(&vLock[i]);
    }

    if (tid == 0) 
        free(vLock);

    #pragma omp barrier
#endif
}
