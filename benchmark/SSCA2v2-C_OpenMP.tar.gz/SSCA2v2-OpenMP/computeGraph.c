#include "defs.h"

double computeGraph(graph* G, graphSDG* SDGdata) {

    VERT_T* endV;
    LONG_T *degree, *numEdges, *pos, *pSums;
    WEIGHT_T* w;
    LONG_T i, j, n, m, tid, nthreads, chunkSize;
    double time;
    omp_lock_t *vLock;

#pragma omp parallel \
private(tid, nthreads, i, j, n, m)
{
    tid = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    
    if (tid == 0)
        time = omp_get_wtime();

    n = N;
    m = M;
    
    if (tid == 0) {
        endV   = (VERT_T *) malloc(m* sizeof(VERT_T));
        degree = (LONG_T *) calloc(n, sizeof(LONG_T));
        numEdges = (LONG_T *) malloc((n+1)*sizeof(LONG_T));
        pos = (LONG_T *) malloc(m*sizeof(LONG_T));
        w = (WEIGHT_T *) malloc(m*sizeof(WEIGHT_T));
        pSums = (LONG_T *) malloc(nthreads*sizeof(LONG_T));
        vLock = (omp_lock_t *) malloc(n*sizeof(omp_lock_t));
    }
  
    #pragma omp barrier
    
    chunkSize = n/nthreads;
    
    #pragma omp for schedule(static, chunkSize)
    for (i=0; i<n; i++) {
        omp_init_lock(&vLock[i]);
    }

    #pragma omp barrier
    
    #pragma omp for schedule(dynamic)
    for (i=0; i<m; i++) {
        LONG_T u = SDGdata->startVertex[i];
        omp_set_lock(&vLock[u]);
        pos[i] = degree[u]++;
        omp_unset_lock(&vLock[u]);
    } 
   
    #pragma omp barrier
    
    prefix_sums(degree, numEdges, pSums, n); 
   
    chunkSize = n/nthreads;
    #pragma omp barrier
 
    #pragma omp for schedule(static, chunkSize)
    for (i=0; i<n; i++) {
        omp_destroy_lock(&vLock[i]);
    }

    if (tid == 0) 
        free(vLock);

    #pragma omp for schedule(static, chunkSize)
    for (i=0; i<m; i++) {
        LONG_T u = SDGdata->startVertex[i];
        j = numEdges[u] + pos[i];
        endV[j] = SDGdata->endVertex[i];
        w[j] = SDGdata->weight[i]; 
    }

    if (tid == 0) {
        free(degree);
        free(pos);
        free(pSums);
        G->n = n;
        G->m = m;
        G->numEdges = numEdges;
        G->endV = endV;
        G->weight = w;
        time = omp_get_wtime() - time;
    }
    
}

    /* Verification */
    /*    
    fprintf(stderr, "SDG data:\n");
    for (i=0; i<SDGdata->m; i++) {
        fprintf(stderr, "[%ld %ld %ld] ", SDGdata->startVertex[i], 
                SDGdata->endVertex[i], SDGdata->weight[i]);
    }
 
    fprintf(stderr, "\n");

    for (i=0; i<G->n + 1; i++) {
        fprintf(stderr, "[%ld] ", G->numEdges[i]);
    }
    
    fprintf(stderr, "\nGraph:\n");
    for (i=0; i<G->n; i++) {
        for (j=G->numEdges[i]; j<G->numEdges[i+1]; j++) {
            fprintf(stderr, "[%ld %ld %ld] ", i, G->endV[j], G->weight[j]);
        }
    }
    */ 

    free(SDGdata->startVertex);
    free(SDGdata->endVertex);
    free(SDGdata->weight);
    return time;
}
