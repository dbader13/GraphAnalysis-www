#include "defs.h"
#define DEBUG 1

double findSubGraphs_simple(graph* G, V** extractedSubGraphs, 
        edge* maxIntWtList, int maxIntWtListSize) {

    LONG_T i, j, k, n, verticesVisited, currIndex, tid;
    char* visited;
    INT_T depth;
    V *VList;
    double time;
    
#if DEBUG
    int *numVisited;
    numVisited = (int *) malloc(maxIntWtListSize*sizeof(int));
#endif

#pragma omp parallel \
private(i, j, k, n, verticesVisited, currIndex, tid) \
private(visited, depth, VList)
{
    n = G->n;
    tid = omp_get_thread_num();
    #pragma omp barrier
    
    if (tid == 0) 
        time = omp_get_wtime();
    
    visited = (char *) calloc(n, sizeof(char));

    /* Each thread runs a BFS from the endVertex of maxIntWtList edgeList */
    #pragma omp for schedule(dynamic)
    for(i=0; i<maxIntWtListSize; i++) {

        VList = extractedSubGraphs[i]; 

        VList[0].num = maxIntWtList[i].startVertex;
        VList[0].depth = -1;

        VList[1].num = maxIntWtList[i].endVertex;
        VList[1].depth = 1;
            
        visited[(VList[0]).num] = (char) 1;
        visited[(VList[1]).num] = (char) 1;

        depth = 1;
        verticesVisited = 2;
        currIndex = 1;

        while ((depth < SubGraphPathLength) || (verticesVisited == n)) {
            depth = VList[currIndex].depth+1;
            for (j=G->numEdges[VList[currIndex].num];
                j<G->numEdges[VList[currIndex].num+1]; j++) {
                if (visited[G->endV[j]] == (char) 0) {
                    visited[G->endV[j]] = (char) 1;
                    VList[verticesVisited].num = G->endV[j];
                    VList[verticesVisited].depth = depth;
                    verticesVisited = verticesVisited + 1;
                }
            }
            if ((currIndex < verticesVisited - 1) && (verticesVisited < n))  {
                currIndex++;
                depth = VList[currIndex].depth;
            } else 
                break;
        }
#if DEBUG
        numVisited[i] = verticesVisited;
#endif
        extractedSubGraphs[i] = VList;

        /* Reset the values of visited array for next iteration */
        for (k=0; k<verticesVisited; k++) {
            visited[VList[k].num] = (char) 0;
        }
    }

    free(visited);
    if (tid == 0)
        time = omp_get_wtime() - time;
}
#if DEBUG
    fprintf(stderr, "No. of vertices visited in each search: ");
    
    for (i=0; i<maxIntWtListSize; i++) {
        fprintf(stderr, "%d ", numVisited[i]);
        /*
        for (j=0; j<numVisited[i]; j++) {
            fprintf(stderr, "[%ld %ld] ", extractedSubGraphs[i][j].num, extractedSubGraphs[i][j].depth);
        }
        fprintf(stderr, "\n");
        */
    }
    free(numVisited);    
#endif
    return time;
}


double findSubGraphs_parBFS(graph* G, V** extractedSubGraphs, 
        edge* maxIntWtList, int maxIntWtListSize) {

    LONG_T i, j, k, n, verticesVisited, currIndex, tid;
    char* visited;
    INT_T depth;
    V *VList;
    double time;
    
#if DEBUG
    int *numVisited;
    numVisited = (int *) malloc(maxIntWtListSize*sizeof(int));
#endif

#pragma omp parallel \
private(i, j, k, n, verticesVisited, currIndex, tid) \
private(visited, depth, VList)
{
    n = G->n;
    tid = omp_get_thread_num();
    #pragma omp barrier
    
    if (tid == 0) 
        time = omp_get_wtime();
    
    visited = (char *) malloc(n*sizeof(char));

    #pragma omp for schedule(dynamic)
    for(i=0; i<maxIntWtListSize; i++) {

        VList = extractedSubGraphs[i]; 

        for (k=0; k<n; k++)
            visited[k] = (char) 0;
    
        VList[0].num = maxIntWtList[i].startVertex;
        VList[0].depth = -1;

        VList[1].num = maxIntWtList[i].endVertex;
        VList[1].depth = 1;
            
        visited[(VList[0]).num] = (char) 1;
        visited[(VList[1]).num] = (char) 1;

        depth = 1;
        verticesVisited = 2;
        currIndex = 1;

        while ((depth < SubGraphPathLength) || (verticesVisited == n)) {
            depth = VList[currIndex].depth+1;
            for (j=G->numEdges[VList[currIndex].num];
                j<G->numEdges[VList[currIndex].num+1]; j++) {
                if (visited[G->endV[j]] == (char) 0) {
                    visited[G->endV[j]] = (char) 1;
                    VList[verticesVisited].num = G->endV[j];
                    VList[verticesVisited].depth = depth;
                    verticesVisited = verticesVisited + 1;
                }
            }
            if ((currIndex < verticesVisited - 1) && (verticesVisited < n))  {
                currIndex++;
                depth = VList[currIndex].depth;
            } else 
                break;
        }
#if DEBUG
        numVisited[i] = verticesVisited;
#endif
        extractedSubGraphs[i] = VList;
    }

    free(visited);
    if (tid == 0)
        time = omp_get_wtime() - time;
}
#if DEBUG
    fprintf(stderr, "No. of vertices visited in each search: ");
    
    for (i=0; i<maxIntWtListSize; i++) {
        fprintf(stderr, "%d ", numVisited[i]);
        /*
        for (j=0; j<numVisited[i]; j++) {
            fprintf(stderr, "[%ld %ld] ", extractedSubGraphs[i][j].num, extractedSubGraphs[i][j].depth);
        }
        fprintf(stderr, "\n");
        */
    }
    free(numVisited);    
#endif
    return time;
}
