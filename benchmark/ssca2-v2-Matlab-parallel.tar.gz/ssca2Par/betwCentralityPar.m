function bc = betwCentralityPar(G, K4approx, sizeParts)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Function betwCentrality() - Kernel 4, analyze a graph's connectivity.
%
% Computes the betweenness centrality for an unweighted graph, using only 
% matrix operations.  Betweenness centrality is a measure of the importance
% of a vertex with respect to the shortest paths between other vertices in
% the graph that it lies on.  This function computes an ordered list of 
% centralities, each centrality corresponding to a specific vertex in the 
% graph. 
%
% The high computational cost of kernel 4:  
% An exact implementation would consider all of the vertices as starting 
% points in the betweenness centrality metric, while this implementation 
% can be 'dialed' to only use a subset of starting vertices. 
%
% For a detailed description of the SCCA #2 graph analysis algorithm, 
% please see SCCA #2 Graph Analysis Written Specification, v2.2.
%
% NOTES: 
%
% This code looks very different to the pseudocode in the written 
% specification, but it is doing the exact same thing.  The only difference
% is that it is vectorized to process a full level in the search tree at a 
% time rather than just a single node.  All of the operations are performed 
% in the same way, only this code is able to perform them in parallel using 
% sparse matrices and matrix operations.
%
% This uses Ulrik Brandes' Algorithm from "A faster algorithm for
% betweenness centrality", where variables are named in the following way:
%   Ulrik Brandes                     Our Algorithm
%   -----------------------------------------------------------------------
%   C_B                               betweennessCentrality
%   P                                 parentsBFS
%   S, Q                              BFS
%   s                                 s
%   sigma                             numShortestPaths
%   d                                 (unused)
%   delta                             bcUpdate
%
% S and Q can be stored using the same variable, because rather than 
% dequeueing a value by popping it from Q and discarding it, an
% array is stored and the queue pointers are updated.  By looking at this
% array in reverse order, S can be produced.
%
% BFS is stored as a matrix rather than an array (queue/stack).  This is
% done because rather than looking at a single node at a time, all nodes at 
% a particular depth are examined.
%
% d is not required.  It was used previously to determine the
% distance between two nodes.  In our implementation, this can be
% determined by looking at bfs.  In addition, since a full level in the
% search is examined at the same time, all previously unseen
% elements at that level must be on shortest paths.
%
% References:
%
% D.A. Bader and K. Madduri, "Parallel Algorithms for Evaluating Centrality 
% Indices in Real-world Networks",  Proc. The 35th International Conference 
% on Parallel Processing (ICPP), Columbus, OH, August 2006.
%
% Ulrik Brandes, "A faster algorithm for betweenness centrality". Journal 
% of Mathematical Sociology, 25(2):163�177, 2001.
%
% L.C. Freeman,  "A set of measures of centrality based on betweenness". 
% Sociometry, 40(1):35�41, 1977.
%
%
% INPUT
%
% G.          - [struct] graph (from kernel 1).
%   adjMatrix - sparse weighted adjacency matrix of the graph.
%
% K4approx    - [int] binary exponent of the number of times that the 
%               algorithm is to loop, between 1 and SCALE. This 
%               simplification reduces its computational time from O(MN) 
%               to O(M*2^K4approx), which is important when testing large 
%               graphs. It determines the amount of work performed by   
%               kernel 4. When 'K4approx' equals 'SCALE', this 
%               implementation is exact.  Otherwise, distinct vertices  
%               are selected randomly (user).
%
%
% OUTPUT
%
% BC          - [1D array, float] Betweenness centrality is a measure of  
%               the importance of a vertex with respect to the shortest 
%               paths between other vertices in the graph it lies on. C is 
% 	            a list of the centralities that were computed (ordered by 
%               vertex number).
% 
%
% REVISION
% 12-Oct-07   1.0 Release   MIT Lincoln Laboratory.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Grab in information for the global data
declareGlobals;

% PAR: Key parallelism off Adjacency Matrix Type
PARALLEL = isa(G.adjMatrix,'dmat');
updateMap = 1;
if (PARALLEL)
	global pMATLAB;
	Ncpus = pMATLAB.comm_size;
	updateMap = map([1 Ncpus],{},0:Ncpus-1);
end

% Allocate the data structures for the computation and initialize variables

% Get the number of vertices of the graph.
N = size(G.adjMatrix,1);

% Convert the adjacency matrix to an unweighted graph, filter the edges
A = logical(mod(G.adjMatrix,8) > 0);
Al = local(A);
if(PARALLEL)
    Ap = sparse(N,N,updateMap);
    Ap = put_local(Ap,local(transpose_grid(A))');
else
    Ap = A';
end
Apl = local(Ap);

% PARALLEL: Initialize the BC
bc = zeros(1,N,updateMap);

if ENABLE_DATA_TYPE == RMAT
    % Preclude the case of '2^K4approx' being greater than N_V
    if (2^K4approx > N)
        K4approx = floor(log2(N));
    end
    nPasses = 2^K4approx;
else % Use the max loop count, for BC verification if a torus
    nPasses = N;
end

% Get the total number of partitions
numParts = ceil(nPasses/sizeParts);

for(p = 1:numParts)
    % Zero out the BFS
    BFS = [];
    
    % The nodes in the partition
    nodesPart = ((p-1).*sizeParts + 1):min(p.*sizeParts,N);
    
    % The size of the partition
    sizePart = length(nodesPart);
    
    % The number of shortest paths from each node
    nsp = zeros(sizePart,N,updateMap);
    for node = 1:sizePart
        nsp(node,nodesPart(node)) = 1;
    end
    
    % Set the counter for the depth in the BFS
    depth = 0;

    % Get the initial fringe
    fringe = sparse(sizePart,N,updateMap);
    fringe = put_local(fringe, double(Al(nodesPart,:)));
    
    % While there are elements at the previous depth to iterate over
    while nnz(fringe) > 0
        depth = depth + 1;
        nsp = nsp + fringe;
        BFS(depth).G = logical(fringe);
        fringe = bcVecMul(fringe,A,depth,1) .* not(nsp);
    end

    % Free up memory.
    clear('fringe');  

    % Pre-compute 1/numShortestPaths
    nspInv = zeros(sizePart,N,updateMap);
    [rows cols vals] = find(local(nsp));
    if(sizePart==1)
        rows = rows';
        cols = cols';
    end
    nspInv = put_local(nspInv,accumarray([rows,cols],1./vals,size(local(nspInv))));
    
    % Free up memory.
    clear('rows','cols','vals');

    % Pre-compute (1+bcUpdate)
    bcu = ones(sizePart,N,updateMap);

    % Compute the BC updates for all nodes except the source nodes
    for depth = depth:-1:2
        weights = (BFS(depth).G .* nspInv) .* bcu;
        bcu = bcu + (bcVecMul(weights,Ap,depth,2) .* BFS(depth-1).G) .* nsp;
    end
    
    % Update the centrality metrics.
    bc = put_local(bc, local(bc) + sum(local(bcu),1));

    % Free up memory.
    clear('weights','nspInv','bcUpdate','BFS');
end

%Subtract off the additional values added in by precomputation
bc = bc - nPasses;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright � 2007, Massachusetts Institute of Technology
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are  
% met:
%    * Redistributions of source code must retain the above copyright
%      notice, this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright
%      notice, this list of conditions and the following disclaimer in the
%      documentation and/or other materials provided with the distribution.
%    * Neither the name of the Massachusetts Institute of Technology nor  
%      the names of its contributors may be used to endorse or promote 
%      products derived from this software without specific prior written 
%      permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS 
% IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
% THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
% PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
% EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
% PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
% PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
% LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
% NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS   
% SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
